jQuery is awesome and it is packaged with Drupal. Luckily, jQuery Mobile exists and is also awesome. So let's use jQuery Mobile (jQM) in DrupalGap!

More information about the use of jQM will be listed here soon. In the mean time, check out how DrupalGap uses [Pages](../Pages) with jQM and how to use [jQM Page Events in DrupalGap](../Pages/Page_Events).
