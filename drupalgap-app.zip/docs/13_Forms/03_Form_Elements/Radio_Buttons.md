Also, check out the [Radio Button Widget](../../Widgets/Radio_Button_Widget) page for other techniques.

![Radio Button Widget](http://www.drupalgap.com/sites/default/files/radio-button-widget.png)

```
form.elements.my_radio_buttons = {
  title: 'Radio Station',
  type: 'radios',
  options: {
    0: 'Rock and Roll',
    1: 'Metal'
  },
  default_value:1
};
```